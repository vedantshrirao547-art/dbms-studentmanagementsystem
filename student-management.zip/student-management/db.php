<?php
// db.php - MySQL connection (included in every page that needs the database)

$host     = "localhost";
$username = "student_app";
$password = "";
$database = "student_db";

$localConfig = __DIR__ . "/db.local.php";
if (is_file($localConfig)) {
    require $localConfig;
}

// Make mysqli throw exceptions so we can use try/catch
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = new mysqli($host, $username, $password, $database);
    $conn->set_charset("utf8mb4");
} catch (mysqli_sql_exception $e) {
    if ($e->getCode() === 1045) {
        $message = "MySQL rejected the configured username or password. Check the credentials in db.php.";
    } elseif ($e->getCode() === 1049) {
        $message = "Database student_db was not found. Import database.sql using phpMyAdmin.";
    } elseif ($e->getCode() === 2002 || $e->getCode() === 2003) {
        $message = "Cannot reach MySQL. Start MySQL in the XAMPP Control Panel.";
    } else {
        $message = "MySQL connection failed (error {$e->getCode()}). Check the XAMPP MySQL settings.";
    }

    die("<h3 style='font-family:Arial;color:#b91c1c;padding:20px'>" . htmlspecialchars($message, ENT_QUOTES, "UTF-8") . "</h3>");
}
?>
