<?php
include "db.php";

$error = "";
// Keep typed values so the form is not emptied after an error
$name = $roll_no = $email = $phone = $course = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name    = trim($_POST["name"]);
    $roll_no = trim($_POST["roll_no"]);
    $email   = trim($_POST["email"]);
    $phone   = trim($_POST["phone"]);
    $course  = trim($_POST["course"]);

    // Server-side validation (JavaScript can be bypassed)
    if ($name == "" || $roll_no == "" || $email == "" || $phone == "" || $course == "") {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif (!preg_match("/^[0-9]{10,15}$/", $phone)) {
        $error = "Phone number must contain 10 to 15 digits.";
    } else {
        try {
            // Prepared statement: ? are placeholders, values are bound safely
            $stmt = $conn->prepare("INSERT INTO students (name, roll_no, email, phone, course) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $name, $roll_no, $email, $phone, $course);
            $stmt->execute();
            $stmt->close();

            header("Location: view_students.php?msg=added");
            exit();
        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() == 1062) {   // 1062 = duplicate entry
                $error = "Roll number already exists.";
            } else {
                $error = "Could not add student. Please try again.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
    <div class="brand">Student Management System</div>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="add_student.php">Add Student</a></li>
        <li><a href="view_students.php">View Students</a></li>
    </ul>
</nav>

<div class="container">
    <h2>Add Student</h2>

    <?php if ($error != ""): ?>
        <div class="message error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <div class="card form-card">
        <form method="POST" action="add_student.php" onsubmit="return validateForm()">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>">
            </div>
            <div class="form-group">
                <label for="roll_no">Roll Number</label>
                <input type="text" id="roll_no" name="roll_no" value="<?php echo htmlspecialchars($roll_no); ?>">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>">
            </div>
            <div class="form-group">
                <label for="phone">Phone</label>
                <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($phone); ?>">
            </div>
            <div class="form-group">
                <label for="course">Course</label>
                <input type="text" id="course" name="course" value="<?php echo htmlspecialchars($course); ?>">
            </div>
            <button type="submit" class="btn">Save Student</button>
            <a href="view_students.php" class="btn btn-gray">Cancel</a>
        </form>
    </div>
</div>

<script src="script.js"></script>
</body>
</html>
