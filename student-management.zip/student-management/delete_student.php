<?php
include "db.php";

// Only accept the delete request sent by the form in view_students.php (POST)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["id"])) {
    $id = (int)$_POST["id"];

    try {
        $stmt = $conn->prepare("DELETE FROM students WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();

        header("Location: view_students.php?msg=deleted");
    } catch (mysqli_sql_exception $e) {
        header("Location: view_students.php?msg=error");
    }
} else {
    header("Location: view_students.php");
}
exit();
?>
