// script.js - basic form validation and delete confirmation

// Called when the Add/Edit form is submitted
function validateForm() {
    var name    = document.getElementById("name").value.trim();
    var rollNo  = document.getElementById("roll_no").value.trim();
    var email   = document.getElementById("email").value.trim();
    var phone   = document.getElementById("phone").value.trim();
    var course  = document.getElementById("course").value.trim();

    if (name === "" || rollNo === "" || email === "" || phone === "" || course === "") {
        alert("Please fill in all the fields.");
        return false;
    }

    // Simple email pattern: text@text.text
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        alert("Please enter a valid email address.");
        return false;
    }

    // Phone: 10 to 15 digits only
    var phonePattern = /^[0-9]{10,15}$/;
    if (!phonePattern.test(phone)) {
        alert("Phone number must contain 10 to 15 digits only.");
        return false;
    }

    return true; // everything is fine, submit the form
}

// Called before deleting a student
function confirmDelete() {
    return confirm("Are you sure you want to delete this student?");
}
