<?php
$host     = "localhost";
$username = "student_app";
$password = "Shrirao@2006";
$database = "student_db";