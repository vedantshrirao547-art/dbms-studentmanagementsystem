<?php
include "db.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Form submitted: update the record
    $id      = (int)$_POST["id"];
    $name    = trim($_POST["name"]);
    $roll_no = trim($_POST["roll_no"]);
    $email   = trim($_POST["email"]);
    $phone   = trim($_POST["phone"]);
    $course  = trim($_POST["course"]);

    if ($name == "" || $roll_no == "" || $email == "" || $phone == "" || $course == "") {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif (!preg_match("/^[0-9]{10,15}$/", $phone)) {
        $error = "Phone number must contain 10 to 15 digits.";
    } else {
        try {
            $stmt = $conn->prepare("UPDATE students SET name=?, roll_no=?, email=?, phone=?, course=? WHERE id=?");
            $stmt->bind_param("sssssi", $name, $roll_no, $email, $phone, $course, $id);
            $stmt->execute();
            $stmt->close();

            header("Location: view_students.php?msg=updated");
            exit();
        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() == 1062) {
                $error = "Roll number already exists.";
            } else {
                $error = "Could not update student. Please try again.";
            }
        }
    }
    $student = ["id" => $id, "name" => $name, "roll_no" => $roll_no,
                "email" => $email, "phone" => $phone, "course" => $course];
} else {
    // Page opened: load the student to show in the form
    if (!isset($_GET["id"])) {
        header("Location: view_students.php");
        exit();
    }
    $id = (int)$_GET["id"];
    $stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $student = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$student) {
        header("Location: view_students.php?msg=error");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
    <div class="brand">Student Management System</div>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="add_student.php">Add Student</a></li>
        <li><a href="view_students.php">View Students</a></li>
    </ul>
</nav>

<div class="container">
    <h2>Edit Student</h2>

    <?php if ($error != ""): ?>
        <div class="message error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <div class="card form-card">
        <form method="POST" action="edit_student.php" onsubmit="return validateForm()">
            <input type="hidden" name="id" value="<?php echo $student["id"]; ?>">

            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($student["name"]); ?>">
            </div>
            <div class="form-group">
                <label for="roll_no">Roll Number</label>
                <input type="text" id="roll_no" name="roll_no" value="<?php echo htmlspecialchars($student["roll_no"]); ?>">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($student["email"]); ?>">
            </div>
            <div class="form-group">
                <label for="phone">Phone</label>
                <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($student["phone"]); ?>">
            </div>
            <div class="form-group">
                <label for="course">Course</label>
                <input type="text" id="course" name="course" value="<?php echo htmlspecialchars($student["course"]); ?>">
            </div>
            <button type="submit" class="btn">Update Student</button>
            <a href="view_students.php" class="btn btn-gray">Cancel</a>
        </form>
    </div>
</div>

<script src="script.js"></script>
</body>
</html>
