<?php
include "db.php";

// Messages sent from other pages, e.g. view_students.php?msg=added
$message = "";
$type = "success";
if (isset($_GET["msg"])) {
    if ($_GET["msg"] == "added")   { $message = "Student added successfully."; }
    if ($_GET["msg"] == "updated") { $message = "Student updated successfully."; }
    if ($_GET["msg"] == "deleted") { $message = "Student deleted successfully."; }
    if ($_GET["msg"] == "error")   { $message = "Something went wrong. Please try again."; $type = "error"; }
}

// Search by name or roll number
$search = isset($_GET["search"]) ? trim($_GET["search"]) : "";

if ($search != "") {
    $like = "%" . $search . "%";
    $stmt = $conn->prepare("SELECT * FROM students WHERE name LIKE ? OR roll_no LIKE ? ORDER BY id DESC");
    $stmt->bind_param("ss", $like, $like);
} else {
    $stmt = $conn->prepare("SELECT * FROM students ORDER BY id DESC");
}
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Students</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
    <div class="brand">Student Management System</div>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="add_student.php">Add Student</a></li>
        <li><a href="view_students.php">View Students</a></li>
    </ul>
</nav>

<div class="container">
    <h2>All Students</h2>

    <?php if ($message != ""): ?>
        <div class="message <?php echo $type; ?>"><?php echo $message; ?></div>
    <?php endif; ?>

    <form class="search-bar" method="GET" action="view_students.php">
        <input type="text" name="search" placeholder="Search by name or roll number"
               value="<?php echo htmlspecialchars($search); ?>">
        <button type="submit" class="btn">Search</button>
        <a href="view_students.php" class="btn btn-gray">Reset</a>
    </form>

    <div class="table-wrap">
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Roll No</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Course</th>
            <th>Actions</th>
        </tr>

        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row["id"]; ?></td>
                <td><?php echo htmlspecialchars($row["name"]); ?></td>
                <td><?php echo htmlspecialchars($row["roll_no"]); ?></td>
                <td><?php echo htmlspecialchars($row["email"]); ?></td>
                <td><?php echo htmlspecialchars($row["phone"]); ?></td>
                <td><?php echo htmlspecialchars($row["course"]); ?></td>
                <td>
                    <a class="btn btn-edit" href="edit_student.php?id=<?php echo $row["id"]; ?>">Edit</a>
                    <form method="POST" action="delete_student.php" onsubmit="return confirmDelete()">
                        <input type="hidden" name="id" value="<?php echo $row["id"]; ?>">
                        <button type="submit" class="btn btn-delete">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="7" class="empty">No students found.</td></tr>
        <?php endif; ?>
    </table>
    </div>
</div>

<script src="script.js"></script>
</body>
</html>
