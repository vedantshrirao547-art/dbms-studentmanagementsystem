-- Student Management System database
CREATE DATABASE IF NOT EXISTS student_db;
USE student_db;

CREATE TABLE IF NOT EXISTS students (
    id      INT PRIMARY KEY AUTO_INCREMENT,
    name    VARCHAR(100) NOT NULL,
    roll_no VARCHAR(50)  NOT NULL UNIQUE,
    email   VARCHAR(100) NOT NULL,
    phone   VARCHAR(20)  NOT NULL,
    course  VARCHAR(100) NOT NULL
);

-- Sample data (optional)
INSERT IGNORE INTO students (name, roll_no, email, phone, course) VALUES
('Amit Patil',  'CS101', 'amit@example.com',  '9876543210', 'Computer Science'),
('Sneha Joshi', 'CS102', 'sneha@example.com', '9123456780', 'Information Technology');
