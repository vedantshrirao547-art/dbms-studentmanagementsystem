<?php
include "db.php";

// Count total students
$result = $conn->query("SELECT COUNT(*) AS total FROM students");
$row = $result->fetch_assoc();
$total = $row["total"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
    <div class="brand">Student Management System</div>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="add_student.php">Add Student</a></li>
        <li><a href="view_students.php">View Students</a></li>
    </ul>
</nav>

<div class="container">
    <h1>Welcome</h1>
    <p class="subtitle">Add, view, edit, delete and search student records.</p>

    <div class="card-grid">
        <div class="card">
            <h3>Total Students</h3>
            <div class="count"><?php echo $total; ?></div>
        </div>
        <div class="card">
            <h3>Add Student</h3>
            <p>Enter a new student's details.</p>
            <a class="btn" href="add_student.php">Add Student</a>
        </div>
        <div class="card">
            <h3>View Students</h3>
            <p>See the list, search, edit or delete.</p>
            <a class="btn" href="view_students.php">View Students</a>
        </div>
    </div>
</div>

<footer>Student Management System | Created by Vedant Shrirao</footer>

</body>
</html>
